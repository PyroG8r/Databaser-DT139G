DROP DATABASE LABBTWO;
CREATE DATABASE LABBTWO;
USE LABBTWO

source create_tables.sql 
source constraints.sql
source inserts.sql  